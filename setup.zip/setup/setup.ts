import { spawn, execSync } from "child_process";
import { writeFileSync } from "fs";

const SERVICE_UUID = "12345678-1234-5678-1234-567812345678";
const CHAR_UUID = "87654321-4321-8765-4321-876543210987";
const WPA_CONF = "/etc/wpa_supplicant/wpa_supplicant.conf";

async function powerOnHardware() {
  console.log("🛠️  Hard-resetting Bluetooth hardware...");
  try {
    execSync("hciconfig hci0 up");
    execSync("rc-service bluetooth restart");
    await new Promise(r => setTimeout(r, 2000));
  } catch (e) {
    console.error("⚠️ Hardware reset warning");
  }
}

async function startGattServer() {
  await powerOnHardware();

  console.log("📡 Initializing unified tinyDJ GATT Stack...");
  const bctl = spawn("bluetoothctl", { shell: true });
  let buffer = "";

  const send = (cmd: string) => bctl.stdin.write(`${cmd}\n`);

  // --- Step 1: Force Single Hardware Identity ---
  setTimeout(() => send("select hci0"), 100);
  setTimeout(() => send("power off"), 500);
  setTimeout(() => send("privacy off"), 1000); // Kills the ghost BB:88 address
  setTimeout(() => send("system-alias 'tinyDJ'"), 1500);
  setTimeout(() => send("power on"), 2500);
  
  // --- Step 2: Clear Stale Advertisements ---
  setTimeout(() => send("advertise off"), 3000); 
  setTimeout(() => send("discoverable on"), 3500);
  setTimeout(() => send("pairable on"), 4000);

  // --- Step 3: Set Advertising Name ---
  setTimeout(() => send("menu advertise"), 5000);
  setTimeout(() => send("clear"), 5500);
  setTimeout(() => send("name 'tinyDJ'"), 6000);
  setTimeout(() => send("back"), 6500);

  // --- Step 4: GATT Service Setup ---
  setTimeout(() => send("menu gatt"), 7500);
  setTimeout(() => send("unregister-application"), 8000);
  setTimeout(() => send(`register-service ${SERVICE_UUID}`), 9000);
  setTimeout(() => send("yes"), 9500);
  setTimeout(() => send(`register-characteristic ${CHAR_UUID} write,write-without-response`), 10500);
  setTimeout(() => send("00"), 11000);
  setTimeout(() => send("register-application"), 12000);
  setTimeout(() => send("back"), 13000);

  // --- Step 5: Final Unified Broadcast ---
  setTimeout(() => send("advertise on"), 14000);
  setTimeout(() => console.log("✨ READY: tinyDJ (B8:27) is now visible."), 15000);

  bctl.stdout.on("data", (data) => {
    const line = data.toString();
    const hexMatch = line.match(/([0-9a-f]{2}\s){3,}/g);

    if (hexMatch) {
      const chunk = hexMatch.join("").replace(/\s/g, "");
      buffer += Buffer.from(chunk, "hex").toString();

      if (buffer.includes("{") && buffer.includes("}")) {
        try {
          const jsonStr = buffer.substring(buffer.indexOf("{"), buffer.lastIndexOf("}") + 1);
          const { ssid, pass } = JSON.parse(jsonStr);
          console.log(`✅ Received Credentials for: ${ssid}`);
          updateWifi(ssid, pass);
          buffer = "";
        } catch (e) { }
      }
    }
  });
}

function updateWifi(ssid: string, pass: string) {
  const config = `ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=wheel
update_config=1
network={
    ssid="${ssid}"
    psk="${pass}"
}\n`;

  try {
    writeFileSync(WPA_CONF, config);
    spawn("wpa_cli", ["-i", "wlan0", "reconfigure"]);
    console.log("📶 WiFi configuration updated & interface reloaded.");
  } catch (err) {
    console.error("❌ WiFi Write Error");
  }
}

startGattServer();
